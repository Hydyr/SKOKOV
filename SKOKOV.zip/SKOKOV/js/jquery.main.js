$(document).ready(function() {
 
  $(".gallery").owlCarousel({
 
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      pagination: true,
      paginationSpeed : 400,
      singleItem:true,
      navigationText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>']
 
      // "singleItem:true" is a shortcut for:
      // items : 1, 
      // itemsDesktop : false,
      // itemsDesktopSmall : false,
      // itemsTablet: false,
      // itemsMobile : false
 
  });
  $(".gallery_1").owlCarousel({
 
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      pagination: false,
      paginationSpeed : 400,
      items : 8, 
      navigationText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>']
      // "singleItem:true" is a shortcut for:
      // items : 1, 
      // itemsDesktop : false,
      // itemsDesktopSmall : false,
      // itemsTablet: false,
      // itemsMobile : false
 
  });

 $('.img-list').masonry({
 // options
  itemSelector: 'li',
  columnWidth: 1
});

$('.image-popup-no-margins').magnificPopup({
    type: 'image',
    closeOnContentClick: true,
    closeBtnInside: false,
    fixedContentPos: true,
    mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
    image: {
      verticalFit: true
    },
    zoom: {
      enabled: true,
      duration: 300 // don't foget to change the duration also in CSS
    }
  });

});